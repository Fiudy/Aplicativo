package com.example.paginainicial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageViewPerfil = findViewById(R.id.imageViewPerfil);
        ImageView imageViewEngrenagem = findViewById(R.id.imageViewEngrenagem);

        imageViewPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Cria uma Intent para abrir a atividade "PerfilActivity"
                Intent intent = new Intent(MainActivity.this, PerfilActivity.class);

                // Inicia a atividade "PerfilActivity"
                startActivity(intent);
            }
        });

        imageViewEngrenagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ConfigActivity.class);

                startActivity(intent);
            }
        });
    }
}
