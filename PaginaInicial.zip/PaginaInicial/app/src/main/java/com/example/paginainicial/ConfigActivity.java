package com.example.paginainicial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ConfigActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.config_main);

        // Referencie os grupos de rádio e os botões de rádio
        RadioGroup radioGroupExercicio = findViewById(R.id.radioGroupExercicio);
        RadioGroup radioGroupVelocidade = findViewById(R.id.radioGroupVelocidade);
        RadioGroup radioGroupOrientacaoMapa = findViewById(R.id.radioGroupOrientacaoMapa);
        RadioGroup radioGroupTipoMapa = findViewById(R.id.radioGroupTipoMapa);

        // Defina um ouvinte de alteração de seleção para cada grupo de rádio
        radioGroupExercicio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Lógica para tratar a seleção do tipo de exercício aqui
                RadioButton radioButton = findViewById(checkedId);
                Toast.makeText(ConfigActivity.this, "Tipo de Exercício selecionado: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        radioGroupVelocidade.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Lógica para tratar a seleção da unidade de velocidade aqui
                RadioButton radioButton = findViewById(checkedId);
                Toast.makeText(ConfigActivity.this, "Unidade de Velocidade selecionada: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        radioGroupOrientacaoMapa.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Lógica para tratar a seleção da orientação do mapa aqui
                RadioButton radioButton = findViewById(checkedId);
                Toast.makeText(ConfigActivity.this, "Orientação do Mapa selecionada: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        radioGroupTipoMapa.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // Lógica para tratar a seleção do tipo de mapa aqui
                RadioButton radioButton = findViewById(checkedId);
                Toast.makeText(ConfigActivity.this, "Tipo de Mapa selecionado: " + radioButton.getText(), Toast.LENGTH_SHORT).show();
            }
        });

        // Referencie o ImageView de voltar (seta)
        ImageView imageViewVoltar = findViewById(R.id.imageViewSeta);

        // Adicione um ouvinte de clique para o ImageView de voltar
        imageViewVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inicie a atividade PaginaInicialActivity quando clicado
                Intent intent = new Intent(ConfigActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
